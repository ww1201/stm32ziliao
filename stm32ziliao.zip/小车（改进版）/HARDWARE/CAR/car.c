#include "car.h"
#include "delay.h"

void cargpio_init()
{
	GPIO_InitTypeDef GPIO_initstructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
	GPIO_initstructure.GPIO_OType = GPIO_OType_PP;
	GPIO_initstructure.GPIO_Mode =GPIO_Mode_OUT;
	GPIO_initstructure.GPIO_Pin =GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
	GPIO_initstructure.GPIO_PuPd=GPIO_PuPd_DOWN;
	GPIO_initstructure.GPIO_Speed =GPIO_Speed_100MHz;
	GPIO_Init(GPIOA,&GPIO_initstructure);
	
	
}
u16 led0pwmval=100; 

void car_back()
{
	led0pwmval=600;
  TIM_SetCompare1(TIM13,led0pwmval);
	IN1=1;
	IN2=0;
	IN3=1;
	IN4=0;
	delay_ms(50);
}

void car_stop()
{
	IN1=0;
	IN2=0;
	IN3=0;
	IN4=0;
	delay_ms(50);
}
void car_move()
{
	led0pwmval=400;
	TIM_SetCompare1(TIM13,led0pwmval);
	IN1=0;
	IN2=1;
	IN3=0;
	IN4=1;
	delay_ms(50);
}

void car_left()
{
	led0pwmval=700;
	TIM_SetCompare1(TIM13,led0pwmval);
	IN1=1;
	IN2=0;
	IN3=0;
	IN4=1;
	delay_ms(150);
}
void car_right()
{
	led0pwmval=700;
	TIM_SetCompare1(TIM13,led0pwmval);
	IN1=0;
	IN2=1;
	IN3=1;
	IN4=0;
	delay_ms(150);
}
void car_decele()
{
	led0pwmval=700;
	 TIM_SetCompare1(TIM13,led0pwmval);
	IN1=0;
	IN2=1;
	IN3=0;
	IN4=1;
	delay_ms(50);
}

void car_accele()
{
	int n=5;
	led0pwmval=100;
	while(n--)
	{
	   led0pwmval+=50;
	   TIM_SetCompare1(TIM13,led0pwmval);
	   IN1=0;
	   IN2=1;
	   IN3=0;
	   IN4=1;
	   delay_ms(50);
	}
}
