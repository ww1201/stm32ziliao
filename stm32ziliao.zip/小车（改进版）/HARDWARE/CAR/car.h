#ifndef __CAR_H
#define __CAR_H
#include "sys.h"
#define IN1 PAout(1)//
#define IN2 PAout(2)//
#define IN3 PAout(3)//
#define IN4 PAout(4)//
#define ENA PAout(6)//
#define ENB PFout(8)//

void cargpio_init(void);
void car_move(void);
void car_left(void);
void car_right(void);
void car_decele(void);
void car_accele(void);
void car_stop(void);
void car_back(void);

#endif

