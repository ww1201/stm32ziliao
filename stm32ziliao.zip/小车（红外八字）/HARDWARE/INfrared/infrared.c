#include "infrared.h"


void infrared_init()
{
	  GPIO_InitTypeDef GPIO_Initstruct;
	  GPIO_Initstruct.GPIO_Pin=GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3;
	  GPIO_Initstruct.GPIO_Mode =GPIO_Mode_IN;
	  GPIO_Initstruct.GPIO_PuPd =GPIO_PuPd_UP;
	  GPIO_Initstruct.GPIO_Speed =GPIO_Speed_100MHz;
	  GPIO_Init(GPIOF,&GPIO_Initstruct);
	 // GPIO_SetBits(GPIOC,GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);

//		 GPIO_Initstruct.GPIO_Pin=GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15|GPIO_Pin_4|GPIO_Pin_0;
//	  GPIO_Initstruct.GPIO_Mode =GPIO_Mode_OUT;
//	  GPIO_Initstruct.GPIO_PuPd =GPIO_PuPd_DOWN;
//	  GPIO_Initstruct.GPIO_Speed =GPIO_Speed_100MHz;
//	  GPIO_Init(GPIOC,&GPIO_Initstruct);	  
//	  GPIO_ResetBits(GPIOC,GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15|GPIO_Pin_4|GPIO_Pin_0);
//	  GPIO_SetBits(GPIOC,GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);
}

