#ifndef _INFRARE_H
#define _INFRARE_H
#include "sys.h"
void infrared_init(void);
//#define INFRARED_0  GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_0)	
#define INFRARED_1  GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_1)	
#define INFRARED_2  GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_2)
#define INFRARED_3  GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_3)	
//#define INFRARED_4  GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_4)	
//#define INFRARED    GPIO_ReadInputData(GPIOC)

#endif

