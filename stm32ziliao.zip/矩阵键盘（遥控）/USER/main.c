#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "lcd.h"
#include "spi.h"
#include "key.h" 
#include "24l01.h"

//ALIENTEK ̽����STM32F407������ ʵ��33
//NRF24L02����ͨ��ʵ��-�⺯���汾
//����֧�֣�www.openedv.com
//�Ա����̣�http://eboard.taobao.com  
//�������������ӿƼ����޹�˾  
//���ߣ�����ԭ�� @ALIENTEK
 
//Ҫд�뵽W25Q16���ַ�������
const u8 TEXT_Buffer[]={"Explorer STM32F4 SPI TEST"};
#define SIZE sizeof(TEXT_Buffer)	 
	
int main(void)
{ 
	u8 key,mode;
	u16 t=0;			 
	u8 tmp_buf[6];
  u8 temp;
	u8 humidity;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);  //��ʼ����ʱ����
	uart_init(115200);	//��ʼ�����ڲ�����Ϊ115200
	LED_Init();					//��ʼ��LED 
 	LCD_Init();					//LCD��ʼ��  
 	KEY_Init();					//������ʼ��
 	NRF24L01_Init();    		//��ʼ��NRF24L01 
 	POINT_COLOR=RED;//��������Ϊ��ɫ 
	LCD_ShowString(30,10,200,16,16,"key1:forward");	
	LCD_ShowString(30,30,200,16,16,"key2:left");
	LCD_ShowString(30,50,200,16,16,"key3:right");	
	LCD_ShowString(30,70,200,16,16,"key4:stop");
	LCD_ShowString(30,90,200,16,16,"key5:back");
  LCD_ShowString(30,110,200,16,16,"key6:accelerate");
  LCD_ShowString(30,130,200,16,16,"key7:decelerate");	
	while(NRF24L01_Check())
	{
		LCD_ShowString(30,130,200,16,16,"NRF24L01 Error");
		delay_ms(200);
		LCD_Fill(30,130,239,130+16,WHITE);
 		delay_ms(200);
	}
	NRF24L01_TX_Mode();
	LED0=1;
	LED1=1;
	LCD_ShowString(30,150,200,16,16,"NRF24L01 OK");
  LCD_ShowString(30,170,200,16,16,"NRF24L01 TX_Mode");	
   while(1)
	 {
		 key=KEY_Scan();
		 temp=key;
		 LCD_ShowNum(30+40,190,key,2,16);
		 switch(key)
		 {
			 case 1:LED1=0;tmp_buf[0]=temp;tmp_buf[5]=0;			
			 if(NRF24L01_TxPacket(tmp_buf)==TX_OK)
			{
				LCD_ShowString(30,220,239,32,16,"Sended DATA:");	
				LCD_ShowNum(30+40,240,tmp_buf[0],2,16); 		   
			}else
			{										   	
 				LCD_Fill(0,220,lcddev.width,170+16*3,WHITE);//�����ʾ			   
				LCD_ShowString(30,220,lcddev.width-1,32,16,"Send Failed "); 
			};
			break;
			 case 2:LED1=0;tmp_buf[0]=temp;
			if(NRF24L01_TxPacket(tmp_buf)==TX_OK)
			{
				LCD_ShowString(30,220,239,32,16,"Sended DATA:");	
				LCD_ShowNum(30+40,240,tmp_buf[0],2,16); 		   
			}else
			{										   	
 				LCD_Fill(0,220,lcddev.width,170+16*3,WHITE);//�����ʾ			   
				LCD_ShowString(30,220,lcddev.width-1,32,16,"Send Failed ");
			};
			break;
			 case 3:LED1=0;tmp_buf[0]=temp;
			if(NRF24L01_TxPacket(tmp_buf)==TX_OK)
			{
				LCD_ShowString(30,220,239,32,16,"Sended DATA:");	
				LCD_ShowNum(30+40,240,tmp_buf[0],2,16); 		   
			}else
			{										   	
 				LCD_Fill(0,220,lcddev.width,170+16*3,WHITE);//�����ʾ			   
				LCD_ShowString(30,220,lcddev.width-1,32,16,"Send Failed ");
			};
			break;
			 case 4:LED1=1;tmp_buf[0]=temp;
			if(NRF24L01_TxPacket(tmp_buf)==TX_OK)
			{
				LCD_ShowString(30,220,239,32,16,"Sended DATA:");	
				LCD_ShowNum(30+40,240,tmp_buf[0],2,16); 		   
			}else
			{										   	
 				LCD_Fill(0,220,lcddev.width,170+16*3,WHITE);//�����ʾ			   
				LCD_ShowString(30,220,lcddev.width-1,32,16,"Send Failed ");
			};
			break;
			 case 5:LED1=1;tmp_buf[0]=temp;
			if(NRF24L01_TxPacket(tmp_buf)==TX_OK)
			{
				LCD_ShowString(30,220,239,32,16,"Sended DATA:");	
				LCD_ShowNum(30+40,240,tmp_buf[0],2,16); 		   
			}else
			{										   	
 				LCD_Fill(0,220,lcddev.width,170+16*3,WHITE);//�����ʾ			   
				LCD_ShowString(30,220,lcddev.width-1,32,16,"Send Failed ");
			};
			break; 
			 case 6:LED1=1;tmp_buf[0]=temp;
			if(NRF24L01_TxPacket(tmp_buf)==TX_OK)
			{
				LCD_ShowString(30,220,239,32,16,"Sended DATA:");	
				LCD_ShowNum(30+40,240,tmp_buf[0],2,16); 		   
			}else
			{										   	
 				LCD_Fill(0,220,lcddev.width,170+16*3,WHITE);//�����ʾ			   
				LCD_ShowString(30,220,lcddev.width-1,32,16,"Send Failed ");
			};
			case 7:LED1=1;tmp_buf[0]=temp;
			if(NRF24L01_TxPacket(tmp_buf)==TX_OK)
			{
				LCD_ShowString(30,220,239,32,16,"Sended DATA:");	
				LCD_ShowNum(30+40,240,tmp_buf[0],2,16); 		   
			}else
			{										   	
 				LCD_Fill(0,220,lcddev.width,170+16*3,WHITE);//�����ʾ			   
				LCD_ShowString(30,220,lcddev.width-1,32,16,"Send Failed "); 
			};
			break;
		 }
	 }
}

