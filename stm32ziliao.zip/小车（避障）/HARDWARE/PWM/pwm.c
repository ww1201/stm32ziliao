#include "pwm.h"
#include "led.h"
#include "usart.h"

u8  TIM4CH1_CAPTURE_STA=0;
u16	TIM3CH1_CAPTURE_VAL;

void TIM_PWM_Init(u32 arr,u32 psc)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM13_Timeinstructure;
	TIM_OCInitTypeDef TIM13_OCInitstructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM13,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF|RCC_AHB1Periph_GPIOA, ENABLE);
	
	GPIO_PinAFConfig(GPIOF,GPIO_PinSource8,GPIO_AF_TIM13);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource6,GPIO_AF_TIM13);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;//LED0��LED1��ӦIO��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIO
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_Init(GPIOF, &GPIO_InitStructure);//��ʼ��GPIO
	
	TIM13_Timeinstructure.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM13_Timeinstructure.TIM_CounterMode =TIM_CounterMode_Up;
	TIM13_Timeinstructure.TIM_Period =arr;
	TIM13_Timeinstructure.TIM_Prescaler =psc;
	TIM_TimeBaseInit(TIM13,&TIM13_Timeinstructure);
	
	TIM13_OCInitstructure.TIM_OCMode=TIM_OCMode_PWM2;
	TIM13_OCInitstructure.TIM_OCPolarity=TIM_OCPolarity_Low;
	TIM13_OCInitstructure.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OC1Init(TIM13,&TIM13_OCInitstructure);
	
	TIM_OC1PreloadConfig(TIM13,TIM_OCPreload_Enable);
	
	TIM_ARRPreloadConfig(TIM13,ENABLE);
	
   TIM_Cmd(TIM13,ENABLE);
}


