#include "chaoshen.h"
#include "lcd.h"
u32 lenght;
void Ultrasound_Init()
{
   
   NVIC_InitTypeDef NVIC_InitStruct;
     EXTI_InitTypeDef EXTI_InitStruct;
   TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
    GPIO_InitTypeDef GPIO_InitStruct;
   RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);
   
   GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
   GPIO_InitStruct.GPIO_Pin=GPIO_Pin_0;
	//GPIO_InitStruct.GPIO_PuPd=GPIO_PuPd_DOWN;
   GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
   GPIO_Init(GPIOE,&GPIO_InitStruct);
   
   GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN;
   GPIO_InitStruct.GPIO_Pin=GPIO_Pin_1;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStruct.GPIO_PuPd=GPIO_PuPd_DOWN;
   GPIO_Init(GPIOE,&GPIO_InitStruct);
   GPIO_ResetBits(GPIOE,GPIO_Pin_1);
	
	//���ö�ʱ��  TIM2
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
   TIM_DeInit(TIM2);   // ��λ��ʱ��2
   
   TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
   TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
   TIM_TimeBaseInitStruct.TIM_Period=65535;
   TIM_TimeBaseInitStruct.TIM_Prescaler=72-1;
   TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct);
   TIM_Cmd(TIM2,DISABLE);
   
	
	// ���� AFIO��ʱ��
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);	//ʹ�ܸ��ù���ʱ��
   // ���� �ж��ߵ�   pe1
   SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource1);
    EXTI_InitStruct.EXTI_Line=EXTI_Line1;
    EXTI_InitStruct.EXTI_LineCmd=ENABLE;
    EXTI_InitStruct.EXTI_Mode=EXTI_Mode_Interrupt;
    EXTI_InitStruct.EXTI_Trigger=EXTI_Trigger_Rising;
    EXTI_Init(&EXTI_InitStruct);
   
   
   NVIC_InitStruct.NVIC_IRQChannel=EXTI1_IRQn;
   NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
   NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=2;
   NVIC_InitStruct.NVIC_IRQChannelSubPriority=1;
   
   NVIC_Init(&NVIC_InitStruct);
   
}


void EXTI1_IRQHandler()
{
   TIM_Cmd(TIM2,ENABLE);
   TIM_SetCounter(TIM2, 0);
   while(Ahead_ECHO_Reci);
      TIM_Cmd(TIM2,DISABLE);
	LCD_Fill(0,250,lcddev.width,170+16*3,WHITE);
	LCD_ShowNum(30+40,250,TIM2->CNT/58,2,16);
	lenght=TIM2->CNT/58;
	EXTI_ClearITPendingBit(EXTI_Line1);
	
}

