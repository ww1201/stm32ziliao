#ifndef _CHAOSHEN_H
#define _CHAOSHEN_H
#include "sys.h"

void Ultrasound_Init(void);
#define Ahead_TRIG_Send PEout(0)
#define Ahead_ECHO_Reci PEin(1)


#endif

